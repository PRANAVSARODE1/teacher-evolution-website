# Microphone Permission Troubleshooting Guide

## 🚨 "Failed to access microphone, please check permissions" Error

This error occurs when your browser doesn't have permission to access your microphone. Here's how to fix it:

## 🔧 Quick Fixes

### 1. **Check Browser Permissions**

#### **Chrome/Edge:**
1. Click the **lock icon** (🔒) in the address bar
2. Set **Microphone** to **Allow**
3. Refresh the page

#### **Firefox:**
1. Click the **shield icon** (🛡️) in the address bar
2. Click **Allow** for microphone permissions
3. Refresh the page

#### **Safari:**
1. Go to **Safari** → **Preferences** → **Websites**
2. Select **Microphone** from the left sidebar
3. Set the website to **Allow**
4. Refresh the page

### 2. **System-Level Permissions**

#### **Windows:**
1. Go to **Settings** → **Privacy** → **Microphone**
2. Ensure **Allow apps to access your microphone** is **ON**
3. Check that your browser is listed and enabled

#### **macOS:**
1. Go to **System Preferences** → **Security & Privacy** → **Privacy**
2. Select **Microphone** from the left sidebar
3. Check the box next to your browser

#### **Linux:**
1. Check your desktop environment's privacy settings
2. Ensure microphone access is enabled for your browser

### 3. **Hardware Issues**

- **Check microphone connection**: Ensure your microphone is properly connected
- **Test microphone**: Use another application to verify it's working
- **Check audio settings**: Ensure the correct microphone is selected as default
- **Update drivers**: Make sure your audio drivers are up to date

### 4. **Browser-Specific Issues**

#### **Chrome:**
- Clear browser cache and cookies
- Disable extensions that might block microphone access
- Try incognito mode

#### **Firefox:**
- Reset permissions: `about:preferences#privacy` → **Permissions** → **Settings**
- Clear site data for the website

#### **Safari:**
- Reset website data: **Safari** → **Preferences** → **Privacy** → **Manage Website Data**

### 5. **HTTPS Requirement**

**Important**: Microphone access requires HTTPS for security reasons.

#### **If using the provided server:**
1. Run `start-server.bat` (Windows) or `python server.py` (Mac/Linux)
2. Open `https://localhost:8443` in your browser
3. Accept the security warning (self-signed certificate)

#### **If using a simple HTTP server:**
- Microphone access will **NOT work** with HTTP
- You must use HTTPS for microphone functionality

### 6. **Common Error Messages**

| Error Message | Solution |
|---------------|----------|
| "NotAllowedError" | User denied microphone permission |
| "NotFoundError" | No microphone found |
| "NotReadableError" | Microphone in use by another app |
| "OverconstrainedError" | Microphone doesn't meet requirements |

### 7. **Step-by-Step Troubleshooting**

1. **First, try these quick fixes:**
   - Refresh the page
   - Allow permissions when prompted
   - Check if microphone works in other apps

2. **If still not working:**
   - Check browser permissions (see section 1)
   - Check system permissions (see section 2)
   - Verify hardware (see section 3)

3. **If using HTTPS server:**
   - Ensure you're accessing `https://localhost:8443`
   - Accept the security certificate warning
   - Try a different browser

4. **Last resort:**
   - Restart your browser
   - Restart your computer
   - Try a different microphone
   - Try a different browser

## 🆘 Still Having Issues?

If none of these solutions work:

1. **Check the browser console** for detailed error messages
2. **Try a different browser** to isolate the issue
3. **Test with a different microphone** if available
4. **Contact your system administrator** if on a managed network

## 📞 Support

For additional help, check the browser's developer console (F12) for detailed error messages that can help identify the specific issue.

---

**Note**: This platform requires both camera and microphone access to function properly. Both permissions must be granted for the assessment to work.
